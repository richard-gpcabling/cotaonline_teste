
<!-- BEGIN NO PRICE MESSAGE -->

<div class="alert alert-warning" role="alert">


	<div class="row">
		<div class="col-md-6">
			<b>Ainda não consegue visualizar o valor dos produtos?</b>
			<br>
			Complete o cadastro de sua empresa.
		</div>
		<div class="col-md-6 text-right">
			<a href="/cliente/edit/<?= $auth['client'] ?>" role="button" class="btn btn-warning" style="margin-top:10px;">
				<span class="glyphicon glyphicon-ok"></span>
				&nbsp;
				Completar cadastro
			</a>
		</div>
	</div>


</div>

<!-- END NO PRICE MESSAGE -->
