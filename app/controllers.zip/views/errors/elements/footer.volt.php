<nav id="footer" class="navbar navbar-default">
<?php if(0){ ?>
    <div class="container-fluid text-center">
        <ul class="nav navbar-nav" style="float:none; display:inline-block;">
            <li><a href="#/">A empresa</a></li>
            <li><a href="#/">Eventos</a></li>
            <li><a href="#/">PSC</a></li>
            <li><a href="#/">Cases</a></li>
            <li><a href="#/">Blog</a></li>
        </ul>
    </div>
<?php } ?>
    <div class="container-fluid text-center">
            <small>
                Policom SP, sede GP Cabling | CNPJ 15.436.940/0001-03<br>
                Rua Costa Aguiar, 1714, Ipiranga — São Paulo | <a href="mailto:contato-policom@gpcabling.com.br">contato-policom@gpcabling.com.br</a>
            </small>
    </div>
</nav>
