<?php

class ElementsController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('');
        parent::initialize();
    }

    public function indexAction()
    {
    }
    public function menuAction()
    {
    }
    public function headerAction()
    {

    }
    public function footerAction()
    {
    }
}
